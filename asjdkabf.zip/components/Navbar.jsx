export default function Navbar() {
    return (
      <nav style={{ background: '#333', color: '#fff', padding: '1rem' }}>
        <h1>School Portal</h1>
      </nav>
    );
  }
  